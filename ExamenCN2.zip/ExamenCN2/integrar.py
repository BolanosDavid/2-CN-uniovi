import numpy as np
import sympy as sym
import numpy.polynomial.polynomial as pol
import matplotlib.pyplot as plt
def dibujoFC(f, a, b, n, metodo='punto_medio'):
    h = (b-a)/n
    fig = plt.figure(figsize=(10, 6))
    xx = np.linspace(a, b, 500)
    plt.plot(xx, f(xx), 'b-', label='Área exacta')
    nodos_totales = []
    
    for i in range(n):
        ai = a + i*h
        bi = ai + h
        
        if metodo == 'punto_medio':
            punto_medio = ai + h/2
            nodos_i = np.array([punto_medio])
            valor = f(punto_medio)
            plt.plot([ai, ai, bi, bi], [0, valor, valor, 0], 'r--')
            plt.fill_between([ai, bi], [0, 0], [valor, valor], color='red', alpha=0.1)
            plt.plot(punto_medio, valor, 'ro', markersize=6)
            nodos_totales.append(punto_medio)
            
        elif metodo == 'trapecio':
            nodos_i = np.array([ai, bi])
            valores = f(nodos_i)
            plt.plot([ai, ai, bi, bi], [0, valores[0], valores[1], 0], 'r--')
            plt.fill_between([ai, bi], [0, 0], [valores[0], valores[1]], color='red', alpha=0.1)
            plt.plot(nodos_i, valores, 'ro', markersize=6)
            nodos_totales.extend([ai, bi])
            
        elif metodo == 'simpson':
            punto_medio = (ai + bi)/2
            nodos_i = np.array([ai, punto_medio, bi])
            valores = f(nodos_i)
            xx_i = np.linspace(ai, bi, 100)
            coef = pol.polyfit(nodos_i, valores, 2)
            yy_i = pol.polyval(xx_i, coef)
            plt.plot(xx_i, yy_i, 'r--')
            plt.plot(nodos_i, valores, 'ro', markersize=6)
            plt.plot([ai, ai], [0, valores[0]], 'r--')
            plt.plot([bi, bi], [0, valores[2]], 'r--')
            plt.plot([punto_medio, punto_medio], [0, valores[1]], 'r--')
            
            nodos_totales.extend([ai, punto_medio, bi])
            
        else:
            return
    nodos_totales = list(dict.fromkeys(nodos_totales))
    plt.grid(True)
    plt.title(f'Fórmula de {metodo.capitalize()} compuesta')
    plt.xlabel('x')
    plt.ylabel('f(x)')
    plt.legend(['Área exacta', 'Puntos de interpolación', 'Área aproximada'])
    plt.tight_layout()
    plt.show()
    
    return fig, np.array(nodos_totales)

def dibujo(f,a,b,nodos):
    plt.figure()
    xp = np.linspace(a,b)
    plt.plot(xp,f(xp),'b',label = 'Área exacta')
    plt.plot([a,a,b,b],[f(a),0,0,f(b)],'b')
    plt.plot(nodos,f(nodos),'ro',label = 'Puntos de interpolación')
    p = np.polyfit(nodos,f(nodos),len(nodos)-1)
    xp = np.linspace(a,b)
    yp = np.polyval(p,xp)
    plt.plot(xp,yp,'r--',label = 'Área aproximada')
    pa = np.polyval(p,a)
    pb = np.polyval(p,b)
    plt.plot([a,a,b,b],[pa,0,0,pb],'r--')
    plt.legend()
    plt.show()
def punto_medio(f,a,b):
    """Metodo del punto medio"""
    I=(b-a)*f((a+b)/2)
    return I

def trapecio(f,a,b):
    """Metodo de trapecio"""
    I = ((b-a)/2)*(f(a)+f(b))
    return I

def simpson(f,a,b):
    """Metodo de simpson"""
    I = ((b-a)/6)*(f(a)+4*f((a+b)/2)+f(b))
    return I
def punto_medio_comp(f, a, b, n):
    """Método del punto medio compuesto"""
    h = (b-a)/n
    suma = 0
    for i in range(n):
        xi = a + i*h
        xi_next = xi + h
        suma += f((xi + xi_next)/2)
    return h * suma

def trapecio_comp(f, a, b, n):
    """Método del trapecio compuesto"""
    h = (b-a)/n
    suma = f(a)/2 + f(b)/2  
    for i in range(1, n):
        xi = a + i*h
        suma += f(xi)
    return h * suma

def simpson_comp(f, a, b, n):
    """Método de Simpson compuesto"""
    if n % 2 != 0:
        return
    h = (b-a)/n
    suma = f(a) + f(b) 
    
    for i in range(1, n):
        xi = a + i*h
        if i % 2 == 0:  
            suma += 2 * f(xi)
        else:
            suma += 4 * f(xi)
    return h/3 * suma
def gauss(f,a,b,n):
   [x, w] = np.polynomial.legendre.leggauss(n)
   y = (b-a)/2 * x + (b+a)/2
   suma = np.sum(w * f(y)) * (b-a)/2  
   return suma
def grado_de_precision(formula,n):
    i = 0
    error = 0.
    x = sym.Symbol('x', real=True)
    
    while i < 20 and error < 1.e-10:
        Ie = float(sym.integrate(x**i,(x,1,3)))
        f = lambda t: t**i
        if(formula.__name__ == 'gauss'):
            Ia = formula(f,1,3,n)
        else:
            Ia = formula(f,1,3)
        error = np.abs(Ie-Ia)
        i += 1
        
        print('f(x) = x^'+str(i-1),'   error = ',error)
        
    print('\nEl grado de precisión de la fórmula es ',i-2) 
def ejercicio1():
    f = lambda x: np.exp(x)
    a,b = 0,3
    nodos = np.array([1,2,2.5])
    dibujo(f,a,b,nodos)
    f = lambda x:np.cos(x)+1.5
    a,b = -3,3
    nodos = np.array([-3.,-1,0,1,3])
    dibujo(f,a,b,nodos)
def ejercicio2():
    f = lambda x: np.log(x)
    a,b = 1,3
    aproximado = punto_medio(f, a, b)
    nodos = np.array([a,b])
    dibujo(f,a,b,nodos)
    print("El valor aproximado es ",aproximado)
    x = sym.Symbol('x', real=True) 
    f_sim = sym.log(x)
    I_exacta =float( sym.integrate(f_sim,(x,a,b)))
    print("\nEl valor exacto es ",I_exacta)
def ejercicio3():
    f = lambda x: np.log(x)
    a,b = 1,3
    aproximado = trapecio(f, a, b)
    nodos = np.array([a,b])
    dibujo(f,a,b,nodos)
    print("El valor aproximado es ",aproximado)
    
    x = sym.Symbol('x', real=True) 
    f_sim = sym.log(x)
    I_exacta =float( sym.integrate(f_sim,(x,a,b)))
    print("\nEl valor exacto es ",I_exacta)
def ejercicio4():
    f = lambda x: np.log(x)
    a,b = 1,3
    aproximado = simpson(f, a, b)
    nodos = np.array([a,(a+b)/2,b])
    dibujo(f,a,b,nodos)
    print("El valor aproximado es ",aproximado)
    x = sym.Symbol('x', real=True) 
    f_sim = sym.log(x)
    I_exacta =float( sym.integrate(f_sim,(x,a,b)))
    print("\nEl valor exacto es ",I_exacta)
def ejercicio5():
    f = lambda x: np.log(x)
    a,b = 1,3
    n = 5
    aproximado = punto_medio_comp(f, a, b, n)
    dibujoFC(f, a, b, n, 'punto_medio')
    print("El valor aproximado es ",aproximado)
    x = sym.Symbol('x', real=True) 
    f_sim = sym.log(x)
    I_exacta =float( sym.integrate(f_sim,(x,a,b)))
    print("\nEl valor exacto es ",I_exacta)
def ejercicio6():
    f = lambda x: np.log(x)
    a,b = 1,3
    n = 4
    aproximado = trapecio_comp(f, a, b, n)
    dibujoFC(f, a, b, n, 'trapecio')
    print("El valor aproximado es ",aproximado)
    x = sym.Symbol('x', real=True) 
    f_sim = sym.log(x)
    I_exacta =float( sym.integrate(f_sim,(x,a,b)))
    print("\nEl valor exacto es ",I_exacta)
def ejercicio7():
    f = lambda x: np.log(x)
    a,b = 1,3
    n = 4
    aproximado = simpson_comp(f, a, b, n)
    dibujoFC(f, a, b, n, 'simpson')

    print("El valor aproximado es ",aproximado)
    x = sym.Symbol('x', real=True) 
    f_sim = sym.log(x)
    I_exacta =float( sym.integrate(f_sim,(x,a,b)))
    print("\nEl valor exacto es ",I_exacta)    

def ejercicio8():
    f = lambda x: np.log(x)
    a,b = 1,3
    n = 3
    for x in range (1,n+1):
       nodos = np.linspace(a,b,x)
       aproximado = gauss(f, a, b, x)
       dibujo(f, a, b, nodos)
       print("El valor aproximado es ",aproximado)
    
def ejercicio9():
    print('\n----  Fórmula del punto medio (1 punto) ----\n')
    grado_de_precision(punto_medio,1)
    print('\n----  Fórmula del trapecio (2 puntos) ----\n')
    grado_de_precision(trapecio,1)
    print('\n----  Fórmula de Simpson (3 puntos) ----\n')
    grado_de_precision(simpson,1)
    print('\n----  gauss n = 1 ----\n')
    grado_de_precision(gauss,1)
    print('\n----  gauss n = 2 ----\n')
    grado_de_precision(gauss,2)
    print('\n----  gauss n = 3 ----\n')
    grado_de_precision(gauss,3)
    print('\n----  gauss n = 4 ----\n')
    grado_de_precision(gauss,4)

def main():
   ejercicio1()
   ejercicio2()
   ejercicio3()
   ejercicio4()
   ejercicio5()
   ejercicio6()
   ejercicio7()
   ejercicio8()
   ejercicio9()
if __name__ == "__main__":
  main()  
