"""Relajacion """

import numpy as np
np.set_printoptions(precision = 8)  
np.set_printoptions(suppress = True)
def relajacion(A, b, w, tol=1e-6, maxiter=1000):
    n = len(b)
    x = np.zeros_like(b)

    for num_iter in range(1, maxiter + 1):
        x_old = x.copy()

        for i in range(n):
            s1 = sum(A[i][j] * x[j] for j in range(i)) 
            s2 = sum(A[i][j] * x_old[j] for j in range(i + 1, n)) 
            x[i] = (1 - w) * x_old[i] + (w / A[i][i]) * (b[i] - s1 - s2)

        if np.linalg.norm(x - x_old, 2) < tol:
            return x, num_iter

    return x, num_iter



# Ejemplo 2
A2 = np.array([[2., 1., 0., 0., 0., 0., 0., 0., 0.],
               [1., 2., 1., 0., 0., 0., 0., 0., 0.],
               [0., 1., 2., 1., 0., 0., 0., 0., 0.],
               [0., 0., 1., 2., 1., 0., 0., 0., 0.],
               [0., 0., 0., 1., 2., 1., 0., 0., 0.],
               [0., 0., 0., 0., 1., 2., 1., 0., 0.],
               [0., 0., 0., 0., 0., 1., 2., 1., 0.],
               [0., 0., 0., 0., 0., 0., 1., 2., 1.],
               [0., 0., 0., 0., 0., 0., 0., 1., 2.]])
b2 = np.array([1., 2., 3., 4., 5., 4., 3., 2., 1.])

x, it = relajacion(A2, b2,1.5)
print("Sistema 2:")
print("Solución aproximada:", x)
print("Iteraciones:", it)
print("Solución exacta:", np.linalg.solve(A2, b2))
