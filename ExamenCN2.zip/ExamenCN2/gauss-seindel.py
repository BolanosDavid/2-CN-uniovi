"""Gauss Seidel"""
import numpy as np
np.set_printoptions(precision = 10)  
np.set_printoptions(suppress = True)
def gauss_seidel(A, b, tol=1e-6, maxiter=1000):
    n = len(b)
    x = np.zeros_like(b, dtype=np.double)
    
    for num_iter in range(1, maxiter + 1):
        x_old = x.copy()

        for i in range(n):
            s1 = sum(A[i][j] * x[j] for j in range(i))    
            s2 = sum(A[i][j] * x_old[j] for j in range(i + 1, n)) 
            x[i] = (b[i] - s1 - s2) / A[i][i]
        
        if np.linalg.norm(x - x_old, 2) < tol:
            return x, num_iter

    return x, num_iter


# Ejemplo 1
A1 = np.array([[5, 1, -1, -1],
               [1, 4, -1, 1],
               [1, 1, -5, -1],
               [1, 1, 1, -4]])
b1 = np.array([1, 1, 1, 1])

x_gs1, it_gs1 = gauss_seidel(A1, b1)
print("Sistema 1:")
print("Solución aproximada:", x_gs1)
print("Iteraciones:", it_gs1)
print("Solución exacta:", np.linalg.solve(A1, b1))
print()

# Ejemplo 2
A2 = np.array([[2., 1., 0., 0., 0., 0., 0., 0., 0.],
               [1., 2., 1., 0., 0., 0., 0., 0., 0.],
               [0., 1., 2., 1., 0., 0., 0., 0., 0.],
               [0., 0., 1., 2., 1., 0., 0., 0., 0.],
               [0., 0., 0., 1., 2., 1., 0., 0., 0.],
               [0., 0., 0., 0., 1., 2., 1., 0., 0.],
               [0., 0., 0., 0., 0., 1., 2., 1., 0.],
               [0., 0., 0., 0., 0., 0., 1., 2., 1.],
               [0., 0., 0., 0., 0., 0., 0., 1., 2.]])
b2 = np.array([1., 2., 3., 4., 5., 4., 3., 2., 1.])

x_gs2, it_gs2 = gauss_seidel(A2, b2)
print("Sistema 2:")
print("Solución aproximada:", x_gs2)
print("Iteraciones:", it_gs2)
print("Solución exacta:", np.linalg.solve(A2, b2))



