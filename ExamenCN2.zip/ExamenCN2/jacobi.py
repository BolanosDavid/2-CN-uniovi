import numpy as np

def jacobi(A, b, tol=1e-6, maxiter=1000):
    n = len(b)
    x = np.zeros_like(b, dtype=np.double)
    xant = np.zeros_like(b, dtype=np.double)

    for num_iter in range(1, maxiter+1):
        for i in range(n):
            s = sum(A[i][j] * xant[j] for j in range(n) if j != i)
            x[i] = (b[i] - s) / A[i][i]
        
        if np.linalg.norm(x - xant, 2) < tol:
            return x, num_iter
        
        xant = x.copy()

    return x, num_iter
A = np.array([[5, 1, -1, -1],
              [1, 4, -1, 1],
              [1, 1, -5, -1],
              [1, 1, 1, -4]])

b = np.array([1, 1, 1, 1])

sol, iters = jacobi(A, b)
print("Solución aproximada:", sol)
print("Número de iteraciones:", iters)
xs = np.linalg.solve(A, b)
print("Solución exacta con numpy:", xs)

# ========================
# Ejemplo 2
# ========================
A2 = np.array([[2., 1., 0., 0., 0., 0., 0., 0., 0.],
               [1., 2., 1., 0., 0., 0., 0., 0., 0.],
               [0., 1., 2., 1., 0., 0., 0., 0., 0.],
               [0., 0., 1., 2., 1., 0., 0., 0., 0.],
               [0., 0., 0., 1., 2., 1., 0., 0., 0.],
               [0., 0., 0., 0., 1., 2., 1., 0., 0.],
               [0., 0., 0., 0., 0., 1., 2., 1., 0.],
               [0., 0., 0., 0., 0., 0., 1., 2., 1.],
               [0., 0., 0., 0., 0., 0., 0., 1., 2.]])

b2 = np.array([1., 2., 3., 4., 5., 4., 3., 2., 1.])

sol2, iter2 = jacobi(A2, b2)
print("Ejemplo 2")
print("Solución aproximada:", sol2)
print("Número de iteraciones:", iter2)
print("Solución exacta con numpy:", np.linalg.solve(A2, b2))