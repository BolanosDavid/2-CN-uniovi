"""Relajacion optimo"""

import numpy as np
import matplotlib.pyplot as plt

def relajacion(A, b, w, tol=1e-12, maxiter=1000):
    n = len(b)
    x = np.zeros_like(b, dtype=np.double)

    for num_iter in range(1, maxiter + 1):
        x_old = x.copy()
        for i in range(n):
            s1 = sum(A[i][j] * x[j] for j in range(i))
            s2 = sum(A[i][j] * x_old[j] for j in range(i + 1, n))
            x[i] = (1 - w) * x_old[i] + (w / A[i][i]) * (b[i] - s1 - s2)

        if np.linalg.norm(x - x_old, 2) < tol:
            return x, num_iter

    return x, maxiter  # No converge en maxiter iteraciones


# Sistema del ejercicio 3
A = np.array([[2, 1, 0, 0, 0, 0, 0, 0, 0],
              [1, 2, 1, 0, 0, 0, 0, 0, 0],
              [0, 1, 2, 1, 0, 0, 0, 0, 0],
              [0, 0, 1, 2, 1, 0, 0, 0, 0],
              [0, 0, 0, 1, 2, 1, 0, 0, 0],
              [0, 0, 0, 0, 1, 2, 1, 0, 0],
              [0, 0, 0, 0, 0, 1, 2, 1, 0],
              [0, 0, 0, 0, 0, 0, 1, 2, 1],
              [0, 0, 0, 0, 0, 0, 0, 1, 2]], dtype=np.double)

b = np.array([1, 2, 3, 4, 5, 4, 3, 2, 1], dtype=np.double)

# Probar para distintos valores de w
w_values = np.arange(0.1, 2.1, 0.01)
num_iters = []

for w in w_values:
    _, num_iter = relajacion(A, b, w, tol=1e-12, maxiter=1000)
    num_iters.append(num_iter)

k = np.argmin(num_iters)
w_opt = w_values[k]

print(f"Óptimo w = {w_opt:.2f}    num_iter = {num_iters[k]}")

plt.figure(figsize=(10, 5))
plt.plot(w_values, num_iters, label='Iteraciones vs ω')
plt.axvline(w_opt, color='r', linestyle='--', label=f'Óptimo ω = {w_opt:.2f}')
plt.xlabel('ω')
plt.ylabel('Número de iteraciones')
plt.title('Búsqueda del ω óptimo para el método de relajacion')
plt.grid(True)
plt.legend()
plt.show()
