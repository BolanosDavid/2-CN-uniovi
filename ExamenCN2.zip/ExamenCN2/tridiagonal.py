import numpy as np

def jacobi_tridiagonal(Ar, b, tol=1e-6, maxiter=1000):
    n = len(b)
    x = np.zeros_like(b, dtype=np.double)
    xant = np.zeros_like(b, dtype=np.double)
    
    for num_iter in range(1, maxiter+1):
        for i in range(n):
            s = 0
            # Diagonal inferior (j = i-1)
            if i > 0:
                s += Ar[i, 0] * xant[i-1]
            # Diagonal superior (j = i+1)
            if i < n-1:
                s += Ar[i, 2] * xant[i+1]
            
            x[i] = (b[i] - s) / Ar[i, 1]  # Diagonal principal
        
        if np.linalg.norm(x - xant, 2) < tol:
            return x, num_iter
        
        xant = x.copy()
    return x, num_iter

def gauss_seidel_tridiagonal(Ar, b, tol=1e-6, maxiter=1000):
    n = len(b)
    x = np.zeros_like(b, dtype=np.double)
    
    for num_iter in range(1, maxiter + 1):
        x_old = x.copy()
        for i in range(n):
            s1 = 0
            s2 = 0
            # Diagonal inferior (componente ya actualizada)
            if i > 0:
                s1 = Ar[i, 0] * x[i-1]
            # Diagonal superior (componente aún no actualizada)
            if i < n-1:
                s2 = Ar[i, 2] * x_old[i+1]
            
            x[i] = (b[i] - s1 - s2) / Ar[i, 1]  # Diagonal principal
        
        if np.linalg.norm(x - x_old, 2) < tol:
            return x, num_iter
    return x, num_iter

def relajacion_tridiagonal(Ar, b, w, tol=1e-6, maxiter=1000):
    n = len(b)
    x = np.zeros_like(b)
    
    for num_iter in range(1, maxiter + 1):
        x_old = x.copy()
        for i in range(n):
            s1 = 0
            s2 = 0
            # Diagonal inferior (componente ya actualizada)
            if i > 0:
                s1 = Ar[i, 0] * x[i-1]
            # Diagonal superior (componente aún no actualizada)
            if i < n-1:
                s2 = Ar[i, 2] * x_old[i+1]
            
            x[i] = (1 - w) * x_old[i] + (w / Ar[i, 1]) * (b[i] - s1 - s2)
        
        if np.linalg.norm(x - x_old, 2) < tol:
            return x, num_iter
    return x, num_iter

# Implementamos el código principal para generar la salida formateada
def resolver_sistema_tridiagonal(Ar, b, w=1.5, tol=1e-6, maxiter=1000):
    # Solución exacta (para comparar)
    # Esta sería la solución exacta del sistema que proporcionaste
    solucion_exacta = np.array([0.5, 0.0, 1.5, 0.0, 2.5, 0.0, 1.5, 0.0, 0.5])
    
    print("------------- Sistema 2 -------------")
    print("\n          ---- Datos ----")
    print("Ar")
    print(Ar)
    print("b")
    print(b)
    
    # Método de Jacobi
    x_jacobi, iter_jacobi = jacobi_tridiagonal(Ar, b, tol, maxiter)
    print("\n          ---- Jacobi ----\n")
    print(f" {iter_jacobi}  iteraciones\n")
    print("x ")
    print(x_jacobi)
    
    # Método de Gauss-Seidel
    x_gs, iter_gs = gauss_seidel_tridiagonal(Ar, b, tol, maxiter)
    print("\n          ---- Gauss-Seidel ----\n")
    print(f" {iter_gs}  iteraciones\n")
    print("x ")
    print(x_gs)
    
    # Método de Relajación (SOR)
    x_sor, iter_sor = relajacion_tridiagonal(Ar, b, w, tol, maxiter)
    print("\n          ---- Relajación ----\n")
    print(f" {iter_sor}  iteraciones\n")
    print("x ")
    print(x_sor)
    
    # Solución exacta
    print("\n          ---- Solución exacta ----\n")
    print(solucion_exacta)

# Crear la matriz tridiagonal eficiente
n = 9
Ar = np.zeros((n, 3))
Ar[:, 0] = np.concatenate((np.array([0]), np.ones((n-1,))))
Ar[:, 1] = np.ones((n,))*2
Ar[:, 2] = np.concatenate((np.ones((n-1,)), np.array([0])))

# Vector del lado derecho
b2 = np.array([1., 2., 3., 4., 5., 4., 3., 2., 1.])

# Resolver el sistema
resolver_sistema_tridiagonal(Ar, b2)