# -*- coding: utf-8 -*-
"""
Created on Mon Mar 17 18:04:19 2025

@author: UO302313
"""
import numpy as np
import matplotlib.pyplot as plt
import numpy.polynomial.polynomial as pol
def lagrange_fundamental(k,x,z):
    p = 1
    for i in range(len(x)):
        if i!=k:
            p*= (z-x[i]) / (x[k]-x[i])
    return p
def polinomio_lagrange(x,y,z):
    resultado=0
    for xi in range(len(x)):
        resultado+= y[xi]*lagrange_fundamental(xi, x, z)
    return resultado
          
        

    
#%% Ejercicio1
def ejercicio1():
    x = np.array([-1., 0, 2, 3, 5])
    y = np.array([ 1., 3, 4, 3, 1])
    k = 2
    z = np.array([1.3, 2.1, 3.2])
    yz = lagrange_fundamental(k,x,z)
    
    yp = np.eye(len(x))
    for i in range(len(x)):
        xx = np.linspace(min(x),max(x))
        yy = lagrange_fundamental(i, x, xx)
        plt.figure()
        plt.plot(xx,yy,'b-', label = 'polinomio interpolante:')
        plt.plot(x,yp[i,:],'r.', markersize=15)
        plt.plot(x, x*0, 'k', label="Eje X")
        plt.legend()
        plt.show()
    pass
#%% Ejercicio2
def ejercicio2():
    x = np.array([-1., 0, 2, 3, 5])
    y = np.array([ 1., 3, 4, 3, 1])
    xx = np.linspace(min(x),max(x))
    yy = polinomio_lagrange(x,y,xx)
    plt.figure()
    plt.plot(xx,yy,'b-', label = 'polinomio interpolante:')
    plt.plot(x,y,'r.', markersize=15,label='puntos')
    plt.legend()
    plt.show()
    x1 = np.array([-1., 0, 2, 3, 5, 6, 7])
    y1 = np.array([ 1., 3, 4, 3, 2, 2, 1])
    xx = np.linspace(min(x1),max(x1))
    yy = polinomio_lagrange(x1,y1,xx)
    plt.figure()
    plt.plot(xx,yy,'b-', label = 'polinomio interpolante:')
    plt.plot(x1,y1,'r.', markersize=15,label='puntos')
    plt.legend()
    plt.show()
    pass
#%%Ejercicio3
def chebyshev(f,a,b,n):
    x = np.linspace(a,b,n)
    
    y = f(x)
    
    xp = np.linspace(min(x),max(x),500)
    p  = pol.polyfit(x,y,len(x)-1)
    yp = pol.polyval(xp,p)
   
    plt.figure()
    plt.axis([-1.05, 1.05, -0.3, 2.3])
    plt.plot(xp,yp,'r-', label = 'polinomio interpolante')
    plt.plot(xp,yy,'b-', label = 'polinomio')
    plt.plot( x, y,'ro', label = 'puntos')
    plt.legend()
   
    plt.show()

    
  
    
def ejercicio3():
    f = lambda x :1 / (1+25*x**2)
    a,b,n = -1,1,11
    chebyshev(f, a, b, n)

    pass
#%%Main
def main():
    ##ejercicio1()
    ##ejercicio2()
    ejercicio3()    
    
if __name__ == "__main__":
  main()  